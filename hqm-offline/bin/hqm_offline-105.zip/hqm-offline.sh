#!/bin/bash

java -jar hqm_offline.jar
